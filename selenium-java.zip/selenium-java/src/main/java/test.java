import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class test {

    WebDriver driver;

    @BeforeTest
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com");
    }

    // Task 1: Login Functionality
    @Test(priority = 1)
    public void loginTest() {

        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();

        String url = driver.getCurrentUrl();
        Assert.assertTrue(url.contains("inventory"));
    }

    // Task 2: Add Product to Cart
    @Test(priority = 2)
    public void addProductToCart() {

        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

        String cartCount = driver.findElement(By.className("shopping_cart_badge")).getText();
        Assert.assertEquals(cartCount, "1");

        driver.findElement(By.className("shopping_cart_link")).click();

        String product = driver.findElement(By.className("inventory_item_name")).getText();
        Assert.assertEquals(product, "Sauce Labs Backpack");

        String price = driver.findElement(By.className("inventory_item_price")).getText();
        Assert.assertEquals(price, "$29.99");
    }

    // Task 3: Sorting
    @Test(priority = 3)
    public void sortingTest() {

        driver.findElement(By.id("continue-shopping")).click();

        WebElement dropdown = driver.findElement(By.className("product_sort_container"));
        Select select = new Select(dropdown);

        select.selectByVisibleText("Price (low to high)");

        String firstPrice = driver.findElements(By.className("inventory_item_price")).get(0).getText();
        String lastPrice = driver.findElements(By.className("inventory_item_price")).get(5).getText();

        double first = Double.parseDouble(firstPrice.replace("$", ""));
        double last = Double.parseDouble(lastPrice.replace("$", ""));

        Assert.assertTrue(first <= last);
    }

    // Task 4: Checkout Flow
    @Test(priority = 4)
    public void checkoutTest() {

        driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();
        driver.findElement(By.className("shopping_cart_link")).click();

        driver.findElement(By.id("checkout")).click();

        driver.findElement(By.id("first-name")).sendKeys("Aditya");
        driver.findElement(By.id("last-name")).sendKeys("Kumar");
        driver.findElement(By.id("postal-code")).sendKeys("144411");

        driver.findElement(By.id("continue")).click();

        String overview = driver.findElement(By.className("title")).getText();
        Assert.assertTrue(overview.contains("Checkout"));

        String total = driver.findElement(By.className("summary_total_label")).getText();
        System.out.println("Total Price: " + total);

        driver.findElement(By.id("finish")).click();

        String msg = driver.findElement(By.className("complete-header")).getText();
        Assert.assertEquals(msg, "Thank you for your order!");
    }

    // Task 5: Logout
    @Test(priority = 5)
    public void logoutTest() throws InterruptedException {

        driver.findElement(By.id("react-burger-menu-btn")).click();
        Thread.sleep(2000);

        driver.findElement(By.id("logout_sidebar_link")).click();

        Assert.assertTrue(driver.getCurrentUrl().contains("saucedemo"));
    }

    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}